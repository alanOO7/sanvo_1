CREATE VIEW `sales_by_film_category` AS
  SELECT
    `c`.`name`        AS `category`,
    sum(`p`.`amount`) AS `total_sales`
  FROM (((((`world`.`payment` `p`
    JOIN `world`.`rental` `r` ON ((`p`.`rental_id` = `r`.`rental_id`))) JOIN `world`.`inventory` `i`
      ON ((`r`.`inventory_id` = `i`.`inventory_id`))) JOIN `world`.`film` `f` ON ((`i`.`film_id` = `f`.`film_id`))) JOIN
    `world`.`film_category` `fc` ON ((`f`.`film_id` = `fc`.`film_id`))) JOIN `world`.`category` `c`
      ON ((`fc`.`category_id` = `c`.`category_id`)))
  GROUP BY `c`.`name`
  ORDER BY `total_sales` DESC