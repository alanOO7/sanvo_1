CREATE VIEW `nicer_but_slower_film_list` AS
  SELECT
    `world`.`film`.`film_id`                                                                            AS `FID`,
    `world`.`film`.`title`                                                                              AS `title`,
    `world`.`film`.`description`                                                                        AS `description`,
    `world`.`category`.`name`                                                                           AS `category`,
    `world`.`film`.`rental_rate`                                                                        AS `price`,
    `world`.`film`.`length`                                                                             AS `length`,
    `world`.`film`.`rating`                                                                             AS `rating`,
    group_concat(concat(concat(upper(substr(`world`.`actor`.`first_name`, 1, 1)),
                               lower(substr(`world`.`actor`.`first_name`, 2, length(`world`.`actor`.`first_name`))),
                               ' ', concat(upper(substr(`world`.`actor`.`last_name`, 1, 1)), lower(
        substr(`world`.`actor`.`last_name`, 2, length(`world`.`actor`.`last_name`)))))) SEPARATOR ', ') AS `actors`
  FROM ((((`world`.`category`
    LEFT JOIN `world`.`film_category`
      ON ((`world`.`category`.`category_id` = `world`.`film_category`.`category_id`))) LEFT JOIN `world`.`film`
      ON ((`world`.`film_category`.`film_id` = `world`.`film`.`film_id`))) JOIN `world`.`film_actor`
      ON ((`world`.`film`.`film_id` = `world`.`film_actor`.`film_id`))) JOIN `world`.`actor`
      ON ((`world`.`film_actor`.`actor_id` = `world`.`actor`.`actor_id`)))
  GROUP BY `world`.`film`.`film_id`, `world`.`category`.`name`